from tools.billing import create_bill, add_bill_item, get_bill


def main():
    print("\n1. Creating multi-item draft bill...")

    bill = create_bill("Ravi")
    print(bill)

    if not bill["success"]:
        return

    bill_id = bill["bill_id"]

    print("\n2. Adding 2 Maggi 70g...")

    result = add_bill_item(
        bill_id=bill_id,
        product_id=1,
        quantity=2
    )
    print(result)

    print("\n3. Adding 1 Tata Salt...")

    result = add_bill_item(
        bill_id=bill_id,
        product_id=3,
        quantity=1
    )
    print(result)

    print("\n4. Getting complete bill...")

    result = get_bill(bill_id)
    print(result)


if __name__ == "__main__":
    main()