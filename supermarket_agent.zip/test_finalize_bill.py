from tools.billing import finalize_bill, get_bill
from tools.inventory import get_stock


def main():

    print("\n1. Finalizing Bill #4...")

    result = finalize_bill(
        bill_id=4,
        payment_mode="upi",
        payment_reference="UPI_TEST_001"
    )

    print(result)

    print("\n2. Checking finalized bill...")

    result = get_bill(4)
    print(result)

    print("\n3. Checking Maggi stock...")

    result = get_stock("Maggi 70g")
    print(result)

    print("\n4. Checking Tata Salt stock...")

    result = get_stock("Tata Salt")
    print(result)


if __name__ == "__main__":
    main()