import sqlite3
from app.database import DB_PATH


def update_database():
    connection = sqlite3.connect(DB_PATH)
    cursor = connection.cursor()

    try:
        cursor.execute("""
            ALTER TABLE bills
            ADD COLUMN cgst_amount REAL DEFAULT 0
        """)

        cursor.execute("""
            ALTER TABLE bills
            ADD COLUMN sgst_amount REAL DEFAULT 0
        """)

        connection.commit()

        print("Database updated successfully.")

    except sqlite3.OperationalError as e:
        print("Database update message:", e)

    finally:
        connection.close()


if __name__ == "__main__":
    update_database()