from app.database import get_connection

conn = get_connection()
cursor = conn.cursor()

try:
    cursor.execute("""
        ALTER TABLE bills
        ADD COLUMN payment_amount REAL DEFAULT 0
    """)

    conn.commit()
    print("Payment amount column added successfully.")

except Exception as e:
    print("Error:", e)

finally:
    conn.close()